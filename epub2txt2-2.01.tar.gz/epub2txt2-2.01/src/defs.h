/*============================================================================
  epub2txt v2 
  defs.h 
  Copyright (c)2017 Kevin Boone, GPL v3.0
============================================================================*/

#pragma once

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef BOOL
typedef int BOOL;
#endif

#ifndef BYTE
typedef unsigned char BYTE;
#endif

